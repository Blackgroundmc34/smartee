import React {useEffect, useState} from "react";

//const DriverLocations = () => {
const DriverList = () => {
const   [drivers, setDrivers] = useState([]);
const [loading, setLoading] = useState(true);
const [error, setError] = useState(null);
//or use const [error, setError] = useState("");
}
useEffect(() => {
    const fetchDrivers = async () => {
        try {
            const response = await fetch('/api/drivers');
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            const data = await response.json();
            setDrivers(data);
        } catch (error) {
            setError(error);
        } finally {
            setLoading(false);
        }
    };

    fetchDrivers();
//if statement to check if latitude and longitude are numbers
if (loading) return <p>Loading...</p>;
if (error) return <p>Error: {error.message}</p>;

    return (
    <div>
        <h1>Driver Locations</h1>
        {loading && <p>Loading...</p>}
        {error && <p>Error: {error.message}</p>}
        <ul>
            {drivers.map(driver => (
                <li key={driver.id}>
                    {driver.name} - {driver.latitude}, {driver.longitude}
                </li>
            ))}
        </ul>
    </div>
);
};

export default DriverList;