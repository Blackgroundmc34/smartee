const AWS = require('aws-sdk');
const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
    const { driverId, latitude, longitude } = JSON.parse(event.body);

    if (typeof latitude !== 'number' || typeof longitude !== 'number') {
        return { statusCode: 400, body: "Missing required parameters" };
    }

    const params = {
        TableName: "DriverLocations",
        Key: { driverId },
        UpdateExpression: "set #lat = :lat, #long = :long",
        ExpressionAttributeNames: {
            ":lat": latitude,
            ":long": longitude
        },
        ExpressionAttributeValues: {
            "#lat": "latitude",
            "#long": "longitude",
            "ts": new Date().toISOString()
        },
    };

    try {
        await dynamo.update(params).promise();
        return { statusCode: 200, body: "Location updated" };
    } catch (err) {
        return { statusCode: 500, body: JSON.stringify(err) };
    }
};
